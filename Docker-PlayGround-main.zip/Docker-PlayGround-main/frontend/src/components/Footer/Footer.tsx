import React from 'react';
import '@styles/Footer.css';

const Footer = () => (
  <div className="footer">
    <p>MobileShop &copy; 2018</p>
  </div>
);

export default Footer;
